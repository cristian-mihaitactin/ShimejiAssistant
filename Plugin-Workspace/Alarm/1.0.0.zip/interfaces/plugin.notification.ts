export interface PluginNotification {
    notificationMessage: string;
    actionType: number,
    data:any
}