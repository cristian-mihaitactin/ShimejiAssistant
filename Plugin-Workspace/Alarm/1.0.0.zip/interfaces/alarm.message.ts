export interface AlarmMessage {
    action:string,
    hour:string,
    minute:string
  };