export interface AlarmModel {
    active:boolean,
    hour:string,
    minute:string
}